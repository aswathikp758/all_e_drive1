<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\RegistrationController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::view('about','about');
Route::view('cart','cart');
Route::view('detail','detail');
Route::view('checkout','checkout');
Route::view('contact','contact');
Route::view('shop','shop');
Route::view('login','login');
Route::view('register','register');
Route::post('create',[RegistrationController::class,'create']);
