<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Registration;

class RegistrationController extends Controller
{
    public function create(Request $req)
    {
        $reg=new Registration;
        $reg->name=$req->name;
        $reg->phonenumber=$req->phonenumber;
        $reg->address1=$req->address1;
        $reg->address2=$req->address2;
        $reg->city=$req->city;
        $reg->state=$req->state;
        $reg->country=$req->country;
        $reg->pincode=$req->pincode;
        $reg->email=$req->email;
        $reg->password=$req->password;
        $reg->save();
    

    }
}
