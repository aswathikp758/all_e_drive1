export default function Home() {
    return(
        <div>Home page</div>
    )
}