import React ,{ useRef , useEffect} from 'react'
// import { motion } from "framer-motion";
 import Navbar from '../Components/Navbar';
// import '../assets/css/style.css';
// import about_image from '../assets/images/about-img.json'
// import circle from '../assets/images/circle.json'
// import Lottie from 'lottie-react';
import Footer from '../Components/footer/Footer'
// import {ImArrowRight} from 'react-icons/im';
// import ab1 from '../assets/images/ab1.jpg'
// import ab2 from '../assets/images/ab2.png'
// import ab3 from '../assets/images/ab3.png'
// import ab4 from '../assets/images/ab4.jpg'
import Aboutcircle from '../Components/Particle/Aboutcircle';
import Aboutpage from '../Components/about/Aboutpage';


export default function About() {
 
  return (
    <div>
      <Navbar/>
      <Aboutcircle/>
      <Aboutpage/>
      
      <Footer/>
      
    </div>
  )
}
