import React from 'react'
import s1 from '../assets/images/s1.jpg';
import s2 from '../assets/images/s2.jpg';
import s3 from '../assets/images/s3.jpg';
import s4 from '../assets/images/s4.jpg';
import Navbar from '../Components/Navbar';
import Footer from '../Components/footer/Footer';

export default function Placements() {
  return (
    <div>
        <Navbar/>
         <div className='container-fluid mt-5 '>
        <center>
        <div className='row mb-5'>
           
            <div className='col-lg-3 '>
                <img src={s1} alt='' width={300} height={200}/>
            </div>
             <div className='col-lg-3'>
                <img src={s2} alt='' width={300} height={200}/>
            </div>
             <div className='col-lg-3' >
                <img src={s3} alt='' width={300} height={200}/>
            </div>
             <div className='col-lg-3' >
                <img src={s4} alt=''width={300} height={200}/>
            </div>
            
        </div>
         <div className='row mb-5'>
           
            <div className='col-lg-3 '>
                <img src={s1} alt='' width={300} height={200}/>
            </div>
             <div className='col-lg-3'>
                <img src={s2} alt='' width={300} height={200}/>
            </div>
             <div className='col-lg-3' >
                <img src={s3} alt='' width={300} height={200}/>
            </div>
             <div className='col-lg-3' >
                <img src={s4} alt=''width={300} height={200}/>
            </div>
            
        </div>
        </center>
    </div>
    <Footer/>
    </div>
   
  )
}
