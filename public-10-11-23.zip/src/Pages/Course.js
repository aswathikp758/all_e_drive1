import React from 'react'
import Navbar from '../Components/Navbar';
import Footer from '../Components/footer/Footer';
import Aboutcircle from '../Components/Particle/Aboutcircle';
import Coursepage from '../Components/course/Coursepage';


export default function Course() {
  return (
    <div>
      <Navbar/>
      <Aboutcircle/>
      <Coursepage/> 
      <Footer/>
    </div>
  )
}
