import React from 'react'
import Navbar from '../Components/Navbar'
import Particle from '../Components/Particle/Particle'
import Squreparticle from '../Components/Particle/Squreparticle'
import Slide from '../Components/slide/Slide'
import Whyus from '../Components/whyus/Whyus'
import Programs from '../Components/programs/Programs'
import Placement from '../Components/placement/Placement'
import TestiMonial from '../Components/testimonials/Testimonial'
import Enquiry from '../Components/enquiry/Enquiry'
import Footer from '../Components/footer/Footer'
import Aboutcircle from '../Components/Particle/Aboutcircle'



export default function Home() {
  return (
    <div>
        <Navbar/>
        <Squreparticle/>
        
        <Slide/>
        <Whyus/>
        <Programs/>
        <Placement/>
        <TestiMonial/>
        {/* <Enquiry/> */}
        <Footer/>
       {/* <Squreparticle/> */}
       
    </div>
  )
}
