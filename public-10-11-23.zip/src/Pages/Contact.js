import React from 'react'
import Navbar from '../Components/Navbar';
import Footer from '../Components/footer/Footer';
import Aboutcircle from '../Components/Particle/Aboutcircle';
import Contactpage from '../Components/contact/Contactpage';



export default function Contact() {
  return (
    <>
        <Navbar/>
        <Aboutcircle/>
        <Contactpage/>
      
      <Footer/>
    </>
  )
}
