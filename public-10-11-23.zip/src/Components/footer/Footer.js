import React from 'react'
import { BsFacebook,BsLinkedin,BsWhatsapp,BsInstagram } from "react-icons/bs";
import {IoMdArrowDropright} from "react-icons/io";
import {BiSolidRightArrow} from "react-icons/bi";
import ScrollToTop from "react-scroll-to-top";
import logo from '../../assets/images/blubay1.png'


export default function Footer() {
  return (
    <div className='bg-footer'>
      <ScrollToTop smooth top="20"/>
       
         <div className='container-fluid  pt-5 ' style={{'backgroundColor':'black'}}>
            <div className='row'>
                <div className='col-lg-3 text-dark text-justify'>
                   
                
                 <ul className='text-secondary' type='none'>
                  <li className='text-dark mb-3'>
                   <img src={logo} alt='' height={40} width={60}/>
                  </li>
                  <li><h4 className='text-white'>BLUBAY SOLUTIONS</h4></li>
                  <li><p className='text-white'>blubay Solutions has been a pioneer of fully-integrated Website designers and developers</p></li>
                 

                 </ul>

                </div>
                <div className='col-lg-3 text-dark'>
                <ul className='text-secondary' type='none'>
                <li className='text-dark pb-2'><h4 className='text-white'>SERVICES</h4></li>  
                <li className='text-white pb-2'><span><BiSolidRightArrow className='nav-arrow'/></span>TRAINING</li>
                <li className='text-white pb-2'><span><BiSolidRightArrow className='nav-arrow'/></span>INTERNSHIP</li>
                <li className='text-white pb-2'><span><BiSolidRightArrow className='nav-arrow'/></span>WEB DEVELOPMENT</li>
                <li className='text-white pb-2'><span><BiSolidRightArrow className='nav-arrow'/></span>PLACEMENTS</li>
                <li className='text-white pb-2'><span><BiSolidRightArrow className='nav-arrow'/></span>LOGO DESIGN</li>
                
                </ul>

                </div>
                <div className='col-lg-3 text-dark'>
                <ul className='text-secondary' type='none'>
                <li className='text-dark pb-2'><h4 className='text-white'>QUICK LINKS</h4></li>  
                <li className='text-white pb-2'><span><BiSolidRightArrow className='nav-arrow'/></span>HOME</li>
                <li className='text-white pb-2'><span><BiSolidRightArrow className='nav-arrow'/></span>ABOUT US</li>
                <li className='text-white pb-2'><span><BiSolidRightArrow className='nav-arrow'/></span>COURSE</li>
                <li className='text-white pb-2'><span><BiSolidRightArrow className='nav-arrow'/></span>PLACEMENTS</li>
                <li className='text-white pb-2'><span><BiSolidRightArrow className='nav-arrow'/></span>GALLARY</li>
                
                </ul>

                </div>
               
                <div className='col-lg-3 text-dark'>
                    <h4 className='text-white'>CONTACT US</h4>
                    <p className='text-white'>
                    7/1152 U, 4th floor, kalpaka building,
                   townhall road, opp crown theatre,calicut

                    Phone: +91 9072663351</p>
                    <p className='text-white'>Email: blubaysolutions@gmail.com
                    </p>
                     <div className='form-inline '><i className='mr-2'><h4 className='text-primary'><BsFacebook className='social-icon '/></h4></i><i className='mr-2'><h4 className='text-primary'><BsWhatsapp className='social-icon'/></h4></i>
                <i className='mr-2'><h4 className='text-primary'><BsLinkedin className='social-icon'/></h4></i><i className='mr-2'><h4 className='text-primary'><BsInstagram className='social-icon'/></h4></i></div>   
                  </div>
                  </div>
         </div>
         <div className='container-fluid copy-section bg-black'>
                    <p className='text-white pl-5 pt-4 '>&copy;2023<span className='text-primary'>BLUBAY SOLUTIONS</span>.All Rights Reserved</p>
                </div>
                </div>
  )
}
