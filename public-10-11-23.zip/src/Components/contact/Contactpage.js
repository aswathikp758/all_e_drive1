import React from 'react'
import {ImArrowRight} from 'react-icons/im';
import cn1 from '../../assets/images/cn1.jpg'
import {BiSolidPhone} from 'react-icons/bi'
import {MdEmail} from 'react-icons/md'
import {ImLocation} from 'react-icons/im'

export default function Contactpage() {
  return (
    <div>
           <div className='container-fluid bg '  style={{'padding':'30px'}}>
        <h1 className='text-center text-white mb-5'>Contact Us</h1>
        <h4 className='text-center text-white'>We are here to help you level up</h4>
        <h6 className='text-white text-center'>We would be happy to Answer your Questions and setup a meeting with you.
        Email us with any questions or enquires or contact our Number.</h6>
        
         <center>
           <div>
            <button className='btn button-style text-white nav-link-style' >Get In Touch<span className='pl-2'><ImArrowRight/></span></button>
        </div>
         </center>
         
         
      </div>
      <div className='container'>
        <div className='row'>
          <div className='col-lg-5'>
            <img src={cn1} alt='' height={500} width={450}/>
          </div>
          <div className='col-lg-7 mt-5'>
            <center>  
            <div className='row mt-5'>
              <h3>Connect with Us</h3>
             <div >
              <h5>Phone</h5>
              <p><span><BiSolidPhone/></span>9072663351</p>
              </div>
              <div >
                <h5>Email</h5>
                <p><span><MdEmail/></span>blubayitsolutions@gmail.com</p>
                </div>
                <div>
                  <h5>Location</h5>
                  <div><span><ImLocation/></span>4th floor, kalpaka building,</div> 
                 <div>&nbsp;&nbsp;opp crown theatre, near town hall road,</div>
                 <div>&nbsp;&nbsp;Kozhikode, Kerala 673001</div>
                </div>

            </div>
            </center>
            


          </div>
        </div>
      </div>
       <div className="container-fluid pt-5 pb-5 pl-5 pr-5" style={{'backgroundColor':'lightgray'}}>
        <div className='row'>
          <div className='col-lg-6'>
            <form style={{'width':'90%','height':'70%'}}>
                <div className="form-group">
                    <input type="email" class="form-control"  placeholder="Name" required/>
                </div>
                <div className="form-group">
                    <input type="password" class="form-control"  placeholder="Contact number" required/>
                </div>
                <div className="form-group">
                  <textarea type="text" className='form-control' placeholder='Message' rows={10} cols={100}></textarea>
                </div>
                <div className='mt-4'>
                   <center><button type="submit" className="btn btn-primary">Submit</button></center>
                </div>
               
            </form>
          </div>
          <div className='col-lg-6'>
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3913.1151486848794!2d75.77693177411125!3d11.25293895022546!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba659393686a527%3A0xf628f6817f2ea572!2sBLUBAY%20SOLUTIONS!5e0!3m2!1sen!2sin!4v1699358354402!5m2!1sen!2sin" width="100%" height="420"  allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

          </div>
        </div>
      </div>
    </div>
  )
}
