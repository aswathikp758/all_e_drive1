import React from 'react'

export default function Enquiry() {
  return (
    <div className='container-fluid pt-5 pb-5' style={{'backgroundColor':'lightgrey'}}>
        <h1 className='text-center'>Enquiry</h1>
        <div className='row'>
           
            <div className='col-lg-6'>
                <form>
                 <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Name</label>
                 <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"/>
                 
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"/>
                   
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Message</label>
                    <textarea type="text" class="form-control" id="exampleInputPassword1"></textarea>
                </div>
               
                <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
            <div className='col-lg-6'>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3913.1151486848794!2d75.77693177411125!3d11.25293895022546!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba659393686a527%3A0xf628f6817f2ea572!2sBLUBAY%20SOLUTIONS!5e0!3m2!1sen!2sin!4v1698923496182!5m2!1sen!2sin" width="500" height="450" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>


    </div>
  )
}
