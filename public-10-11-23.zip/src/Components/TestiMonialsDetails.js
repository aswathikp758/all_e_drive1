import React from 'react';

const TestiMonialsDetails = ({testiMonialDetail}) => {
    const {name, address, description, img} = testiMonialDetail;
    console.log("testiMonialDetail"+testiMonialDetail)
    return (
        <div className="item">
            <div className="shadow-effect">
                <img className="img-circle" src={img} alt=''/>
                <p>{description}</p>
            </div>
            <div className="testimonial-name">
                <h5>{name}</h5>
                <small>{address}</small>
            </div>
        </div>
    );
};

export default TestiMonialsDetails;



// import React from 'react';
// import s1 from '../assets/images/s1.png'

// const TestiMonialsDetails = ({testiMonialDetail}) => {
//     const {name, address, description, img} = testiMonialDetail;
//     console.log("testiMonialDetail"+testiMonialDetail)
//     return (
//         <div className="item" style={{'padding':'3%'}}>
//             <div className="shadow-effect">
//                 <img className="img-circle" src={img} alt=''/>
//                  <h5 className='text-dark'>{name}</h5>
//                 <img src={s1} alt=''/>
//                 <p className='text-dark'>{description}</p>
//             </div>
//             {/* <div className="testimonial-name">
//                 <h5>{name}</h5>
//                 <small>{address}</small>
//             </div> */}
//         </div>
//     );
// };

// export default TestiMonialsDetails;