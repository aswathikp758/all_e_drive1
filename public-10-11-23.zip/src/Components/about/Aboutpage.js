import React ,{ useRef , useEffect} from 'react'
import { motion } from "framer-motion";

import '../../assets/css/style.css';
import about_image from '../../assets/images/about-img.json'
import circle from '../../assets/images/circle.json'
import Lottie from 'lottie-react';

import {ImArrowRight} from 'react-icons/im';
import ab1 from '../../assets/images/ab1.jpg'
import ab2 from '../../assets/images/ab2.png'
import ab3 from '../../assets/images/ab3.png'
import ab4 from '../../assets/images/ab4.jpg'


export default function Aboutpage() {
  return (
      <div>
         <div className='container-fluid bg' style={{'padding':'30px'}}>
        {/* <Lottie animationData={circle} loop={true} height={10} width={10}/> */}
        <h1 className='text-center text-white mb-5'>About Us</h1>
        <p className='text-white text-center'>Blubay solutions keeps culture and creativity at the heart of everything we do.
        Our mission is to help candidates unlock thier creativity and build exceptional content usingour uniquely powerful design platform
        and our tirelessly helpful support and education resources and do it 
        all without writing a single line of code.</p>
         <center>
           <div>
            <button className='btn button-style text-white nav-link-style' >Get In Touch<span className='pl-2'><ImArrowRight/></span></button>
        </div>
         </center>
         
         
      </div>
      <div className='container-fluid'>
        <div className='row'>
        <div className='col-lg-6' >
            <Lottie animationData={about_image} loop={true} height={100} width={100}/>
        </div>
        <div className='col-lg-6'>
           <p className=' pt-5 mt-5 text-justify'>Blubay solutions is an advanced Computer Training Institute has been educating computer professionals for long time  and has launched numerous successful careers in the field of information technology.
         The company employs talented instructors, who are seasoned IT professionals and bring depth of real workplace knowledge to their classrooms. We have built modern training facilities 
          </p>
          <p className='text-justify'>Our approach is to provide rigorous theoretical training while teaching our students extensive practical skills. We make every effort to prepare our students to face the challenges of today's
          rapidly evolving information technology marketplace. Our training manuals and exercise materials are very effective in enhancing students' knowledge and skills base. Students can take any of our courses separately or combine several of them to achieve higher levels of proficiency in information technology. Our instructors are not just experienced teachers, they are team leaders and senior technical developers who themselves mentor and coach new employees and consultants hired on their projects.
          We are committed to providing the best professional education to our students and to turn them into knowledgeable and successful information technology professionals. For that reason our company invests in new facilities, the latest software and newest hardware and hires talented teachers and assistants.
          </p>
        </div>

      </div>
      </div>
      <div className='container mb-5'>
        
       <div className='row'>
          <div class="card-deck">
                <div class="card ab-card">
                    <img src={ab1} alt=''  class="card-img-top"/>
                    <div class="card-body">
                        <h5 class="card-title text-center">Individual Class</h5>
                       
                    </div>
                   
                </div>
                <div class="card ab-card">
                    <img src={ab2} alt='' class="card-img-top"/>
                    <div class="card-body">
                        <h5 class="card-title text-center">Technical Sections</h5>
                      
                    </div>
                  
                </div>

                <div class="card ab-card">
                    <img src={ab3} alt='' class="card-img-top"/>
                    <div class="card-body">
                        <h5 class="card-title text-center">Free Demo Class</h5>
                       
                    </div>
                  
                </div>

                <div class="card ab-card">
                    <img src={ab4} alt='' class="card-img-top"  style={{'width':'250px','height':'250px'}}/>
                    <div class="card-body">
                        <h5 class="card-title text-center">100% Placements</h5>
                           </div>
                  
                </div>
            </div>
       </div>
      </div>
      
      </div>
  )
}
