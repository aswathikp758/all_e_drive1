import React, { useState } from 'react'
import './programs.style.css';
import c1 from '../../assets/images/c1.png'
import c2 from '../../assets/images/c2.png'
import c3 from '../../assets/images/c3.png'
import c4 from '../../assets/images/c4.png'
import c5 from '../../assets/images/c5.png'
import c6 from '../../assets/images/c6.png'
import c7 from '../../assets/images/c7.png'
import {motion} from 'framer-motion';
import { CircleGrid,Donut } from 'react-awesome-shapes';

export default function Programs() {
    const [isFlipped,setIsFlipped]=useState(false);
    const [isAnimating,setIsAnimating]=useState(false);

    function handleFlip(){
        if(!isAnimating){
            setIsFlipped(!isFlipped)
            setIsAnimating(true)
        }
    }
  return (
    <div className='mt-5 mb-5'>
        <h1 className='text-center font-weight-bold' style={{'marginBottom':'100px'}}>Trending Courses</h1>
        <div className='skew-c'></div>
        <div style={{'width':'100%','height':'auto'}} className='div-bg'>
             <div className='container' >
        
                    <motion.div className='row'
                       initial={{opacity:0,scale:0}}
                        whileInView={{opacity:1,scale:1}}
                        transition={{duration:2}}
                        viewport={{once:true}} 
                    >
                        <center>
                         <motion.div className="col-lg-3  person" style={{'backgroundColor':'white','paddingTop':'20px'}}
                         whileHover={{scale:1.1}} transition={{layout:{
                            duration:1,
                            type:"spring"
                         }}}
                         >
                    <img src={c1} className="card-img-top" alt="..."/>
                    <h4>WEB DESIGNING</h4>
                    <p>Create a Website using HTML ,css and bootstrap framework with photoshop and javascript. </p>
                    </motion.div>
                    <motion.div className="col-lg-3  person" style={{'backgroundColor':'white'}}
                     whileHover={{scale:1.1}} transition={{layout:{
                            duration:1,
                            type:"spring"
                         }}}
                    >
                    <img src={c2} className="card-img-top" alt="..."/>
                    <h4>PHP-LARAVEL </h4>
                     <p>Backend Create using PHP and with their Laravel web application framework  </p>
                    </motion.div>
                    <motion.div className="col-lg-3  person" style={{'backgroundColor':'white','paddingTop':'50px'}}
                     whileHover={{scale:1.1}} transition={{layout:{
                            duration:1,
                            type:"spring"
                         }}}
                    >
                     <img src={c3} className="card-img-top" alt="..."/>
                    <h4>PYTHON-DJANGO </h4>
                     <p>Django provides a powerful form library that handles rendering forms as HTML</p>
                     
                    </motion.div>
                    <motion.div className="col-lg-3  person" style={{'backgroundColor':'white','paddingTop':'50px','paddingBottom':'10px'}}
                     whileHover={{scale:1.1}} transition={{layout:{
                            duration:1,
                            type:"spring"
                         }}}
                    >
                     <img src={c4} className="card-img-top" alt="..."/>
                    <h4>MERN FULLSTACK</h4>
                     <p>MERN is a framework made up of the stack of MongoDB, Express.js, React.js, and Nodejs</p>
                    </motion.div>
                    </center>
                    </motion.div>
                    {/* <Donut
                    color="#f43f5e"
                    size="180px"
                    width={['40px', '40px', '60px', '60px']}
                    zIndex={2} /> */}
                     <motion.div className='row pb-5'  initial={{opacity:0,scale:0}}
                        whileInView={{opacity:1,scale:1}}
                        transition={{duration:2}}
                        viewport={{once:true}} >
                        <center>
                         <motion.div className="col-lg-3  person1" style={{'backgroundColor':'white'}}
                          whileHover={{scale:1.1}} transition={{layout:{
                            duration:1,
                            type:"spring"
                         }}}
                         >

                    <img src={c5} className="card-img-top" alt="..."/>
                    <h4>PHP-LARAVEL+REACT FULLSTACK</h4>
                    <p>Backend Create using PHP and with their Laravel web application framework</p>
                    </motion.div>
                    <motion.div className="col-lg-3  person1" style={{'backgroundColor':'white'}}
                     whileHover={{scale:1.1}} transition={{layout:{
                            duration:1,
                            type:"spring"
                         }}}
                    >
                    <img src={c6} className="card-img-top" alt="..."/>
                    <h4>PYTHON-DJANGO+REACT FULLSTACK</h4>
                    <p>Django provides a powerful form library that handles rendering forms as React</p>
                    </motion.div>
                    <motion.div className="col-lg-3  person1" style={{'backgroundColor':'white','paddingTop':'22px'}}
                     whileHover={{scale:1.1}} transition={{layout:{
                            duration:1,
                            type:"spring"
                         }}}
                    >
                     <img src={c7} className="card-img-top" alt="..."/>
                    <h4>REACT</h4>
                    <p >React js is a web designing technology ,this is a library for web and native user interfaces. Build user interfaces out of individual pieces called components written in JavaScript.

                    </p>
                    
                    </motion.div>
                     <div className="col-lg-3 person2" >
                   
                    </div>
                   
                    </center>
                     {/* <CircleGrid
                    position="relative"
                    top="0"
                    left="70%"
                    color="#10b981"
                    size="50px"
                    zIndex={2}
                   
                     /> */}
                    </motion.div>
                   
   


    </div>
        </div>

    </div>
  )
}

