import React from 'react'
import {BiSolidPhone,BiLogoFacebook,BiLogoWhatsapp,BiLogoInstagram} from 'react-icons/bi'
import {AiOutlineMail} from 'react-icons/ai'
import '../assets/css/style.css';
import logo from '../assets/images/blubay1.png';
import { Link, NavLink } from 'react-router-dom';
import {ImArrowRight} from 'react-icons/im';

export default function Navbar() {
  return (
    <div>
    <div className='container-fluid'>
        <div className='row bgnav '>
            <div className='col-lg-2 d-none d-sm-block'><h3 className='text-white navfont'><span><BiSolidPhone/></span>+91 9072663351</h3></div>
            <div className='col-lg-3 d-none d-sm-block' ><h3 className='text-white navfont' style={{'marginLeft':'-45px'}}><span className='mr-1'><AiOutlineMail/></span>blubayitsolutions@gmail.com</h3></div>
            <div className='col-lg-2'></div>
             <div className='col-lg-3'></div> 
            <div className='col-lg-2'><h3 className='text-white navfont' style={{'marginRight':'0px'}} >Follow Us:<span className='navfont2'><BiLogoFacebook className='text-sm-center'/><BiLogoWhatsapp/><BiLogoInstagram/></span></h3></div>
        </div>
       </div>
<nav className="navbar navbar-expand-md navbar-dark sticky-top" style={{'backgroundColor':'white'}}>
        <img src={logo} alt='' height={50} width={70}/>
        <a href="#" className="navbar-brand"><span className='text-primary' >BLUBAY SOLUTIONS</span></a>
        <button type="button" className="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarCollapse">
            <div className="navbar-nav" style={{'margin-left': '30%'}}> 
              <NavLink to="/" className="nav-item nav-link nav-size " style={({ isActive, isPending }) => {return {color: isActive ? "darkblue" : "#00CCFF", fontWeight: isPending ? "bold" : "",}; }} >HOME</NavLink>
               <NavLink to="/about" className="nav-item nav-link nav-size" style={({ isActive, isPending }) => {return {color: isActive ? "darkblue" : "#00CCFF", fontWeight: isPending ? "bold" : "",}; }}>ABOUT</NavLink>
               <NavLink to="/course" className="nav-item nav-link nav-size" style={({ isActive, isPending }) => {return {color: isActive ? "darkblue" : "#00CCFF", fontWeight: isPending ? "bold" : "",}; }} >COURSE</NavLink>
               <NavLink to="/placements" className="nav-item nav-link nav-size" style={({ isActive, isPending }) => {return {color: isActive ? "darkblue" : "#00CCFF", fontWeight: isPending ? "bold" : "",}; }}>PLACEMENTS</NavLink>
              <NavLink to="/contact" className="nav-item nav-link nav-size" style={({ isActive, isPending }) => {return {color: isActive ? "darkblue" : "#00CCFF", fontWeight: isPending ? "bold" : "",}; }}>CONTACT</NavLink>
              </div>
            <div className='ml-auto'>
           <NavLink to="/contact">
             <button className='btn button-style text-white nav-link-style' >Get In Touch<span className='pl-2'><ImArrowRight/></span></button>
           </NavLink>
           
        </div>
           
        </div>
    </nav>
</div>
  )
}
