import React from 'react';
import s1 from '../assets/images/s1.png'

const PlacementDetails = ({testiMonialDetail}) => {
    const {name, address, description, img} = testiMonialDetail;
    console.log("testiMonialDetail"+testiMonialDetail)
    return (
        <div className="mr-3 mb-3">
            <div className="shadow-effect2" style={{'zIndex':'0'}}>
                <img  src={img} alt='' className='img-circle2 ' width={200} height={250}/>
                {/* <img src={s1} alt=''/> */}
                {/* <p className='text-dark'>{description}</p> */}
            </div>
            <div className="testimonial-name mt-4">
                <h5>{name}</h5>
                <small>{address}</small>
            </div>
        </div>
    );
};

export default PlacementDetails;