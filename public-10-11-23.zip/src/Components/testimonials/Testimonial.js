import React, { useEffect, useState } from 'react';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import u1 from '../../assets/images/u1.png'
import u2 from '../../assets/images/u2.png'
import u3 from '../../assets/images/u3.png'
import u4 from '../../assets/images/u4.png'

import '../../assets/css/testimonials.css'

import TestiMonialsDetails from '../TestiMonialsDetails';



const TestiMonial = () => {
  
    const testiMonials = [
        {
            name: 'Rekob Ramya',
            description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s.',
            address: 'USA',
            img: 'https://i.ibb.co/hgGJc8d/Gareth-Bale.jpg'
        },
        {
            name: 'Brandon Savage',
            description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s.',
            address: 'USA',
            img: 'https://i.ibb.co/z7Kp6yr/np-file-33188.jpg'
        },
        {
            name: 'Steve Burns',
            description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s.',
            address: 'USA',
            img: 'https://i.ibb.co/CP5sj7g/2856040-58866808-2560-1440.jpg'
        },
        {
            name: 'Kevin Canlas',
            description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s.',
            address: 'USA',
            img: 'https://i.ibb.co/10SYccm/1552313010-354215-noticia-normal.jpg'
        },
    ]
    //Owl Carousel Settings
    const options = {
        loop: true,
        center: true,
        items: 3,
        margin: 0,
        autoplay: true,
        dots: true,
        autoplayTimeout: 8500,
        smartSpeed: 450,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            1000: {
                items: 3
            }
        }
    };
    return (
        <section id="testimonial" className="testimonials pt-70 pb-70">
            <div className="container mt-5">
                <h4 className="miniTitle text-center">TESTIMONIALS</h4>
                <div className="text-center ">
                    <h3 className="sectionTitle">What Our Clients are Saying?</h3>
                </div>
                <p className="text-center ">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
                <div className="row">
                    <div className="col-md-12">
                        <OwlCarousel id="customer-testimonoals" className="owl-carousel owl-theme" {...options}>
                            {
                                testiMonials.length === 0 ?
                                    <div class="item">
                                        <div class="shadow-effect">
                                            <img class="img-circle" src={u1} alt=''/>

                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
                                        </div>
                                        <div class="testimonial-name">
                                            <h5>Rajon Rony</h5>
                                            <small>ITALY</small>
                                        </div>
                                    </div> :
                                    testiMonials.map(testiMonialDetail => {
                                        return (
                                            <TestiMonialsDetails testiMonialDetail={testiMonialDetail} key={testiMonialDetail._key} />

                                        )
                                    })
                            }
                        </OwlCarousel>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default TestiMonial;


// import React, { useEffect, useState } from 'react';
// import OwlCarousel from 'react-owl-carousel';
// import 'owl.carousel/dist/assets/owl.carousel.css';
// import 'owl.carousel/dist/assets/owl.theme.default.css';
// import u1 from '../../assets/images/u1.png'
// import u2 from '../../assets/images/u2.png'
// import u3 from '../../assets/images/u3.png'
// import u4 from '../../assets/images/u4.png'

// import '../../assets/css/testimonials.css'

// import TestiMonialsDetails from '../TestiMonialsDetails';

// const TestiMonial = () => {
  
//     const testiMonials = [
//         {
//             name: 'SHABNA KC',
//              description: 'Excellent service providers.Blubay is very good place to learn and develop our knowledge level.Specially good faculties and also providing quick placement.',
           
//             address: 'USA',
//             img: `${u1}`
//         },
//         {
//             name: 'AFZAL KP',
//             description: 'Dedicated staffs. One of the Best PHP Training center and HR Consultancy. Right place to enhance our knowledge. Special Thanks to my Faculties. Thank You Blubay.',
//             address: 'USA',
//             img: `${u2}`
//         },
//         {
//             name: 'SWARNA LAL',
//              description: 'Excellent service providers.Blubay is very good place to learn and develop our knowledge level.Specially good faculties and also providing quick placement.',
           
//             address: 'USA',
//            img: `${u3}`
//         },
//         {
//             name: 'ANU MS',
//             description: 'Excellent service providers.Blubay is very good place to learn and develop our knowledge level.Specially good faculties and also providing quick placement.',
           
//             address: 'USA',
//              img: `${u4}`
           
//         },
//     ]
//     //Owl Carousel Settings
//     const options = {
//         loop: true,
//         center: true,
//         items: 3,
//         margin: 0,
//         autoplay: true,
//         dots: true,
//         autoplayTimeout: 8500,
//         smartSpeed: 450,
//         nav: false,
//         responsive: {
//             0: {
//                 items: 1
//             },
//             600: {
//                 items: 3
//             },
//             1000: {
//                 items: 3
//             }
//         }
//     };
//     return (
//         <section id="testimonial" className="testimonials mt-5 bg-light">
//             <div className="container ">
//                 <h4 className="miniTitle text-center pt-5">TESTIMONIALS</h4>
//                 <div className="text-center ">
//                     <h3 className="sectionTitle">What Our Students are Saying?</h3>
//                 </div>
              
//                 <div className="row" style={{'marginTop':'-90px'}}>
//                     <div className="col-md-12">
//                         <OwlCarousel id="customer-testimonoals" className="owl-carousel owl-theme" {...options}>
//                             {
//                                 testiMonials.length === 0 ?
//                                     <div className="item">
//                                         <div className="shadow-effect">
//                                             <img class="img-circle" src={u1} alt=''/>
                                           

//                                             <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
//                                         </div>
//                                         <div class="testimonial-name">
//                                             <h5>Rajon Rony</h5>
//                                             <small>ITALY</small>
//                                         </div>
//                                     </div> :
//                                     testiMonials.map(testiMonialDetail => {
//                                         return (
//                                             <TestiMonialsDetails testiMonialDetail={testiMonialDetail} key={testiMonialDetail._key} />

//                                         )
//                                     })
//                             }
//                         </OwlCarousel>
//                     </div>
//                 </div>
//             </div>
//         </section>
//     );
// };

// export default TestiMonial;