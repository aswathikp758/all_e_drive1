import React, { useEffect, useState } from 'react';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import u1 from '../../assets/images/u1.png'
import u2 from '../../assets/images/u2.png'
import u3 from '../../assets/images/u3.png'
import u4 from '../../assets/images/u4.png'
import PlacementDetails from '../PlacementDetails';
import s1 from '../../assets/images/s1.jpg'
import s2 from '../../assets/images/s2.jpg'
import s3 from '../../assets/images/s3.jpg'
import s4 from '../../assets/images/s4.jpg'
import p1 from '../../assets/images/place.png'

// import '../../assets/css/placements.css';

const Placementcard = () => {
     const testiMonials = [
        {
             name: 'AISWARYA',
             address: 'WEB DESIGNER',
            img: `${s1}`
        },
        {
             name: 'BASITH',
             address: 'WEB DESIGNER',
            img: `${s2}`
        },
        {
             name: 'AMRUTHA',
           address: 'WEB DESIGNER',
           img: `${s3}`
        },
        {
             name: 'ANJALI',
             address: 'PHP DEVELOPER',
             img: `${s4}`
           
        },
    ]
     const options = {
        loop: true,
        center: true,
        items: 3,
        margin: 0,
        autoplay: true,
        dots: true,
        autoplayTimeout: 8500,
        smartSpeed: 450,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            1000: {
                items: 3
            }
        }
    };
  return (
        <section id="testimonial" className="testimonials">
            <div className="container ">
                 <div className="row" >
                    <div className="col-md-12">
                        <OwlCarousel id="customer-testimonoals" className="owl-carousel owl-theme" {...options}>
                            {
                                testiMonials.length === 0 ?
                                    <div class="item">
                                        {/* <div class="shadow-effect">
                                            <img class="img-circle" src={s1} alt=''/>
                                           

                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
                                        </div>
                                        <div class="testimonial-name">
                                            <h5>Rajon Rony</h5>
                                            <small>ITALY</small>
                                        </div> */}
                                    </div> :
                                    testiMonials.map(testiMonialDetail => {
                                        return (
                                            <PlacementDetails testiMonialDetail={testiMonialDetail} key={testiMonialDetail._key} />
                                        )
                                    })
                            }
                        </OwlCarousel>
                    </div>
                </div>
            </div>
        </section>
  )
}

export default Placementcard