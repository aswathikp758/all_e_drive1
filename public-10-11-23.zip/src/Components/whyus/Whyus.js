import React from 'react'
import img1 from '../../assets/images/logo1.png';
import img2  from '../../assets/images/logo2.png';
import img3 from '../../assets/images/logo3.png';
import img4 from '../../assets/images/logo4.png';
import { motion } from 'framer-motion';
import './whyus.style.css';
import {FcCollaboration,FcGraduationCap,FcManager,FcConferenceCall} from 'react-icons/fc';

export default function Whyus() {
  return (
    <motion.div 
       initial={{opacity:0,scale:0}}
       whileInView={{opacity:1,scale:1}}
       transition={{duration:2}}
       viewport={{once:true}} 
     className='container' style={{'marginTop':'5%'}}>
        <h4 className='text-center mb-5 font-weight-bold' style={{'fontSize':'35px'}}>Why BLUBAY</h4>
        <center>
                    <div className='card-deck'>
           <div className="card border-style bg-card"  style={{'width': '18rem'}}>
            {/* <img src={img1} className="card-img-top" alt="..."/> */}
            <h1 className='text-center' style={{'width':'600','height':'600'}}><FcConferenceCall/></h1>
            <div className="card-body">
                <h5 className="card-title">Expert Level Training</h5>
                <p className="card-text">Our Expert Trainers will provide you to live classes and doubt clearence section.</p>
                
            </div>
            </div>
             <div className="card border-style bg-card" style={{'width': '18rem'}}>
            {/* <img src={img2} className="card-img-top" alt="..."/> */}
             <h1 className='text-center' style={{'width':'600','height':'600'}}><FcGraduationCap/></h1>
            <div className="card-body">
                <h5 className="card-title">Build Better Career</h5>
                <p className="card-text">Our Training programs will helps to build your better career</p>
                
            </div>
            </div>
             <div className="card border-style bg-card" style={{'width': '18rem'}}>
            {/* <img src={img3} className="card-img-top" alt="..."/> */}
             <h1 className='text-center' style={{'width':'600','height':'600'}}><FcManager/></h1>
            <div className="card-body">
                <h5 className="card-title">Assured Placements</h5>
                <p className="card-text">We will provide 100% Placement assistance to you.</p>
              
            </div>
            </div>
             <div className="card border-style bg-card" style={{'width': '18rem'}}>
            {/* <img src={img4} className="card-img-top" alt="..."/> */}
             <h1 className='text-center' style={{'width':'600','height':'600'}}><FcCollaboration/></h1>
            <div className="card-body">
                <h5 className="card-title">Individual classes</h5>
                <p className="card-text">We have both Online and Offline classes.Each classes are Individual.</p>
              
            </div>
            </div>
        </div>
        </center>


    </motion.div>
  )
}
