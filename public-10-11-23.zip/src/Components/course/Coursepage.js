import React from 'react'
import {ImArrowRight} from 'react-icons/im';
import {motion} from 'framer-motion';
import c1 from '../../assets/images/c1.png'
import c2 from '../../assets/images/c2.png'
import c3 from '../../assets/images/c3.png'
import c4 from '../../assets/images/c4.png'
import c5 from '../../assets/images/c5.png'
import c6 from '../../assets/images/c6.png'
import c7 from '../../assets/images/c7.png'
import Lottie from 'lottie-react';
import findcourse from '../../assets/images/findcourse.json'
import '../../assets/css/style.css'

export default function Coursepage() {
  return (
    <div>
           <div className='container-fluid bg' style={{'padding':'30px'}}>
        {/* <Lottie animationData={circle} loop={true} height={10} width={10}/> */}
        <h1 className='text-center text-white mb-5'>All Courses</h1>
        <p className='text-white text-center' style={{'font-size':'20px'}}>Blubay has expertise who can work with you to understand your time to time needs and get back to you with effective Web development. We Capture all your thoughts and coloring your thoughts and create before you as best ever Website</p>
         <center>
           <div>
            <button className='btn button-style text-white nav-link-style' >Get In Touch<span className='pl-2'><ImArrowRight/></span></button>
        </div>
        
         </center>
         
         
      </div>
  <div className='mt-5'>
        <h1 className='text-center' style={{'marginBottom':'100px'}}>Trending Courses</h1>
       
        <div style={{'width':'100%','height':'auto'}} className='div-bg1'>
             <div className='container' >
        
                    <motion.div className='row'
                       initial={{opacity:0,scale:0}}
                        whileInView={{opacity:1,scale:1}}
                        transition={{duration:2}}
                        viewport={{once:true}} 
                    >
                        <center>
                         <motion.div className="col-lg-3  person" style={{'backgroundColor':'white','paddingTop':'20px'}}
                         whileHover={{scale:1.1}} transition={{layout:{
                            duration:1,
                            type:"spring"
                         }}}
                         >
                    <img src={c1} className="card-img-top" alt="..."/>
                    <h4>WEB DESIGNING</h4>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    </motion.div>
                    <motion.div className="col-lg-3  person" style={{'backgroundColor':'white'}}
                     whileHover={{scale:1.1}} transition={{layout:{
                            duration:1,
                            type:"spring"
                         }}}
                    >
                    <img src={c2} className="card-img-top" alt="..."/>
                    <h4>PHP-LARAVEL </h4>
                     <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    </motion.div>
                    <motion.div className="col-lg-3  person" style={{'backgroundColor':'white','paddingTop':'50px'}}
                     whileHover={{scale:1.1}} transition={{layout:{
                            duration:1,
                            type:"spring"
                         }}}
                    >
                     <img src={c3} className="card-img-top" alt="..."/>
                    <h4>PYTHON-DJANGO </h4>
                     <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                     
                    </motion.div>
                    <motion.div className="col-lg-3  person" style={{'backgroundColor':'white','paddingTop':'50px','paddingBottom':'10px'}}
                     whileHover={{scale:1.1}} transition={{layout:{
                            duration:1,
                            type:"spring"
                         }}}
                    >
                     <img src={c4} className="card-img-top" alt="..."/>
                    <h4>MERN FULLSTACK</h4>
                     <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    </motion.div>
                    </center>
                    </motion.div>
                     <motion.div className='row'  initial={{opacity:0,scale:0}}
                        whileInView={{opacity:1,scale:1}}
                        transition={{duration:2}}
                        viewport={{once:true}} >
                        <center>
                         <motion.div className="col-lg-3  person1" style={{'backgroundColor':'white'}}
                          whileHover={{scale:1.1}} transition={{layout:{
                            duration:1,
                            type:"spring"
                         }}}
                         >

                    <img src={c5} className="card-img-top" alt="..."/>
                    <h4>PHP-LARAVEL+REACT FULLSTACK</h4>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    </motion.div>
                    <motion.div className="col-lg-3  person1" style={{'backgroundColor':'white'}}
                     whileHover={{scale:1.1}} transition={{layout:{
                            duration:1,
                            type:"spring"
                         }}}
                    >
                    <img src={c6} className="card-img-top" alt="..."/>
                    <h4>PYTHON-DJANGO+REACT FULLSTACK</h4>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    </motion.div>
                    <motion.div className="col-lg-3  person1" style={{'backgroundColor':'white','paddingTop':'22px'}}
                     whileHover={{scale:1.1}} transition={{layout:{
                            duration:1,
                            type:"spring"
                         }}}
                    >
                     <img src={c7} className="card-img-top" alt="..."/>
                    <h4>REACT</h4>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                     <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    </motion.div>
                     <div className="col-lg-3 person2">
                   
                    </div>
                    </center>
                    
                    </motion.div>
                   
   


    </div>
        </div>

          </div>
          <div className='container-fluid bg-course mt-5'>
            <div className='row'>
              <div className='col-lg-6'>
                 <Lottie animationData={findcourse} loop={true} height={100} width={100}/>
              </div>
              <div className='col-lg-6' style={{'marginTop':'40px'}}>
                <p className='text-white'>demo text</p>
                <h1 className='text-white mb-5'>Find your course</h1>
                <form style={{'width':'70%'}}>
                  <div className='form-group'><input type="text" className='form-control' placeholder='Your Name'/></div>
                  <div className='form-group'><input type="text" className='form-control' placeholder='Contact Number'/></div>
                  <center><button className='btn btn-primary'>Submit</button></center> 
                </form>
              </div>
            </div>
          </div>
    </div>
  )
}
