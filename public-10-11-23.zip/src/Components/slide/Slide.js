import React from 'react'
import slide1 from '../../assets/images/slide2.png';
import '../../assets/css/style.css';
import {motion} from 'framer-motion';
import {ImArrowRight} from 'react-icons/im';

export default function Slide() {
  return (
    <div className='container-fluid'>
        <div className='row'>
            <motion.div 
             variants={{
          hidden:{opacity:0,y:75},
          visible:{opacity:1,y:0},
        }}
        initial="hidden"
        animate="visible"
        transition={{duration:0.5,delay:1}}
            className='col-lg-7' style={{'marginRight':'-40px','marginTop':'100px'}}>
                <h1 className='pt-5 text-white display-4 pb-3 text-center' style={{'fontWeight':'bold'}}>Elegant and creative solutions</h1>
                <h5 className='text-white pb-3 text-center'>We are team of talented designers making websites with Bootstrap</h5>
                <p className='text-white text-center'> Lorem Ipsum has been the industry's standard dummy text ever since software like Aldus PageMaker including versions of Lorem Ipsum.
                 like Aldus PageMaker including versions of Lorem Ipsum.
                  like Aldus PageMaker including versions of Lorem Ipsum.</p>
                   <div style={{'marginTop':'40px'}}>
                    <center>
                        <button className='btn button-style text-white nav-link-style'>Get In Touch<span className='pl-2'><ImArrowRight/></span></button>
                    </center>
          
        </div>
                
            </motion.div>
            <div className='col-lg-5' style={{'marginLeft':'-50px','marginTop':'50px'}}><img src={slide1} alt='' className='img-fluid vert-move'/></div>
        </div>

    </div>
  )
}
