import React from 'react'
import './aboutcircle.style.css';

export default function Aboutcircle() {
  return (
    <div className='center'>
       <div className='loading'>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
       </div>
    </div>
  )
}
