import React from 'react'
import './particle.css';

export default function Squreparticle() {
  return (
    <div className='body'>
        <div className='wrapper'>
           
            <div className='box'>
               <div></div>
               <div></div>
               <div></div>
               <div></div>
               <div></div>
               <div></div>
               <div></div>
               <div></div>
               <div></div>
               <div></div>


            </div>
        </div>

    </div>
  )
}
