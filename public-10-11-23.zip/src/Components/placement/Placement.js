import React from 'react'
import Marquee from 'react-fast-marquee'
import s1 from '../../assets/images/s1.jpg'
import s2 from '../../assets/images/s2.jpg'
import s3 from '../../assets/images/s3.jpg'
import s4 from '../../assets/images/s4.jpg'
import banner_logo from '../../assets/images/banner-logo.png'
import Lottie from 'lottie-react';
import Pla from '../../assets/images/pla.json'
import TestiMonial from '../testimonials/Testimonial'
import Placementcard from '../testimonials/Placementcard'
import place from '../../assets/images/place-imgg.gif'


export default function Placement() {
  return (
    <div  className='mt-2 container-fluid'>

       <h1 className='text-center mb-5 mt-5'>Our Placements</h1> 
       <div className='row'>
        <div className='col-lg-4 '>
             {/* <Lottie animationData={Pla} loop={true} height={100} width={100}/> */}
             <img src={place} alt='' height={500} width={400}/>
        </div>
        <div className='col-lg-8'>
               <div>
            {/* <Marquee>
                <div>
                    <img src={s1} alt='' height={300} width={300} className='mr-5'/>
                </div>
                <div>
                    <img src={s2} alt='' height={300} width={300} className='mr-5'/>
                </div>
                <div>
                    <img src={s3} alt='' height={300} width={300} className='mr-5'/>
                </div>
                <div>
                    <img src={s4} alt=''height={300} width={300} className='mr-5'/>
                </div>
            </Marquee> */}
            <Placementcard/>
          
        </div>
        <center>
            <div><button className='btn btn-primary mt-5'>View More</button></div>
        </center>
        </div>
       </div>
     
        
        
    </div>
  )
}

