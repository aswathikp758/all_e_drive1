def index(name):
    print("hello,"+name)

person1={
    "name":"abc",
    "age":36,
    "country":"india"
}