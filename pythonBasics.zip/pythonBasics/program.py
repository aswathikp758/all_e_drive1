# # x=5
# # X = "hai"
# # y = "hello"
# #
# # print(x)
# # print(X)
# # print(y)
# # print(type(x))
# # print(type(y))
#
# #
# # x=str(3)
# # y=int(3)
# # z=float(3)
# # print(x)
# # print(y)
# # print(z)
# # #
# # a, b, c = "html", "css", "js"
# # print(a, b, c)
# # print(b)
# # print(c)
# # #
# # a = b = c = "html"
# # print(a)
# # print(b)
# # print(c)
# # # unpacking
# # language = ["html", "css", "js"]
# # x, y, z = language
# # print(x)
# # print(y)
# # print(z)
# # #
# # #
# # x = 5
# # y = 5
# # print(x + y)
# # #
# # x = "world"
#
# # def index():
# #     x = "hai"
# #     print("hello" + x)
# #
# #
# # index()
# # print(x)
# # # #
# # a = "hello"
# # print(a)
# # #
# a = "hello world"
# # print(len(a))
# # # #
# # print(10 > 9 & 10>20)
# # print(10 == 9)
# # #
# # print(10 + 3)
# # #
# # mylist = ["a", "b", "c", 1]
# # print(mylist)
# # #
# # print(len(mylist))
# # #
# # mytuple = ("a", "b", "c")
# # print(mytuple)
# # print(type(mytuple))
# # # #
# # myset = {"a", "b", "c"}
# # print(myset)
# # # #
# # mydict = {"letter": "a",
# #           "number": 1}
# # print(mydict["number"])
#
#
# # #
# # #a = 33
# # b = 33
# # if a > b:
# #     print("a is greater than b")
# # elif a == b:
# #     print("a equal to b")
# # else:
# #     print("ok")
# # #
# # i = 1
# # while i < 6:
# #     print(i)
# #     i += 1
# #
# # language = ["html", "css", "js"]
# # for x in language:
# #     print(x)
# #
# #
# # #
# # #
# # def index(fname, lname):
# #     print(fname + " " + lname)
# #
# # index("hello", "hai")
# #
# # #
# # # #
# # def my_function(abc):
# #  for x in abc:
# #     print(x)
# # # #
# # # # #
# # letters=["a","b","c"]
# # my_function(letters)
# # # #
#
#
#
# # class abc():
# #     x = 5
# #     y = 10
# #     z = 20
# #
# #     def index(self):
# #         print("hello")
# #
# # a=abc()
# # print(a.x)
# # print(a.y)
# # a.index()
# # a.x=60
# # print(a.x)
# # del a.x
# # print(a.x)
# # #
#
#
# #constructor
# # class person:
# #     "program for person"
# #
# #     def __init__(self, name, age):
# #         self.name = name
# #         self.age = age
# #
# # #
# # obj = person("abc", 30)
# # print(obj.name)
# # print(obj.__doc__)
# #
# #Destructor
# # class A(object):
# #     def __init__(self):
# #         self.str1 = "abc"
# #         print('object created', self.str1)
# #
# #     def __del__(self):
# #         print("destructor")
# # ob = A()
# # del ob
#
# #
# # class Student:
# #     def sum(self, a=None, b=None):
# #         s = a + b
# #         return s
# #
# #
# # s1 = Student()
# # print(s1.sum(5, 25))
# #
# #
# class person:
#     def __init__(self, fname, lname):
#         self.firstname = fname
#         self.lastname = lname
#
#     def printname(self):
#         print(self.firstname, self.lastname)
#
# x = person("john", "k")
# x.printname()
#
#
# class Student(person):
#     pass
#
#
# x = Student("abi", "k")
# x.printname()
# #
# #
# class Language:
#     def lang(self):
#         print("programing language")
#
#
# class Html(Language):
#     def lang(self):
#         print("markup language")
#
#
# class Css(Language):
#     def lang(self):
#         print("stylesheet language")
#
#
# # class Python(Language):
# #     def lang(self):
# #         print("development language")
#
#
# # Html = Language()
# # Html.lang()
# # css = Css()
# # css.lang()
# # # py = Python()
# # # py.lang()
# #
# #
# # #
# class student:
#     def sum(self, a=None, b=None, c=None):
#         s = a + b + c
#         return s
# #
# #
# s1 = student()
# print(s1.sum(5, 6, 7))
# #
# #
# # #
# class A:
#       a = 10
#       _b = 20
#       __c = 30
#       def method(self):
#           print(self.a)
#           print(self._b)
#           print(self.__c)
# #
# #
# class B(A):
#     def method(self):
#         print(self.a)
#         print(self._b)
#         print(self.__c)
# #
# #
# x = B()
# x.method()
# # #
# # #
# # #
# # # # file handling
# # # f=open("demofile.txt")
# #
# # # f=open("demofile.txt","w")
# # # f.write("now the file has more content")
# # # f.close()
# # # f=open("demofile.txt","r")
# # # print(f.read())
# # #
# # # f=open("myfiles.txt","x")
# # # import os
# # # import re
# #
# #
# # # if os.path.exists("demofile.txt"):
# # #     os.remove("demofile.txt")
# # # else:
# # #     print("the file does not exist")
# #
# # # os.rmdir("mydir")
# # # os.getcwd()
# # # print(os.getcwd())
# # #
# # # os.chdir("C://Users/anand/PycharmProjects/pythonBasics/mydir")
# # # print(os.getcwd())
# # #
# # # f = os.listdir("C://Users/anand/PycharmProjects/pythonBasics")
# # # print(f)
# # # os.mkdir('test')
# # # f=os.listdir()
# # # print(f)
# #
# #
# # # os.rename('test','new_one')
# # # f=os.listdir()
# # # print(f)
# #
# # # os.remove("myfile.txt")
# # # f=os.listdir()
# # # print(f)
# --------------------RegEx-------------
import re
#
txt = "The rain in Spain"
x = re.search("^The.*Spain$", txt)
if x:
    print("yes,match")
else:
    print("no match")
#
txt = "The rain in Spain"
x = re.sub("\s", "9", txt)
print(x)
#
txt = "The rain in Spain"
x = re.split("\s",txt)
print(x)
#
#
txt="The rain in Spain"
x=re.findall("ai",txt)
print(x)
#
pattern='^a...s$'
text='abyss'
result=re.match(pattern,text)
if result:
    print("search success")
else:
    print("unsuccess")

#
