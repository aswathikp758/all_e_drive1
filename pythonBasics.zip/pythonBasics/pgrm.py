x=10
y="abc"
z=2.3
print(x)
X=100
print(X)
print(type(z))

x=str(3)
print(x)
print(type(x))


a,b,c="html","css","python"
print(a)
print(c)


# a=b=c="php"
print(c)

# language=["html","css","python"]
# x,y,z=language
# print(z)


# x="5"
# y="5"
# print(x+y)


# x=5
# y=5
# print(x+y)

# x=10
# y=20
# z=x
# x=y
# y=z
# print(x)
# print(y)


if 5>2:
  print("5 is greater than 2")


x="programing language"
def index():
    print("python is   "+  x)

index()

def home():
   x = "markup language"
   print("html is "+x)

home()
print(x)


a="hello"
print(len(a))

mylist=["a","b","c",34,"5.6"]
print(mylist[1])

mytuple=("a","b","c")
print(mytuple)
print(len(mytuple))

myset={"a","b","c"}
print(myset)
print(len(myset))

mydict={"name":"abc",
        "age":"23",
        "location":"calicut"}
print(mydict["name"])
print(mydict["age"])
print(len(mydict))
print(type(mydict))


# a=33
# b=33
# if b>a:
#     print("b is greater than a")
#
# if b>a:
#     print("b is greater than a")
# elif a==b:
#     print("a  equal to b")
# else:
#     print("error")
#

i=1
while i<6:
    print(i)
    i+=1

language=["html","css","js"]
for x in language:
    print(x)

def my_function(fname,lname):
    print(fname +" "+ lname)



my_function("sas","k")


def my_fun1(*lang):
    print("popular language is  "+lang[2])

my_fun1("html","css","python")

def about(child1,child2,child3):
    print("the child is"+child3)

about(child1="a",child2="b",child3="c")

def my_fn(**lang):
    print("language is "+lang["fname"])

my_fn(fname="a",lname="b")

def index(food):
    for x in food:
        print(x)

fruits=["apple","orange","banana"]

index(fruits)

class abc:
    x=5

p1=abc()
print(p1.x)

class home:
    x=5
    y=10
    z=20
    def index(self):
        print("helllo")

h=home()
print(h.z)
h.index()
h.x=50
print(h.x)
del h.x
print(h.x)

class person:
    "program for person"
    def __init__(self,name,age):
        self.nm=name
        self.age=age

obj=person("sam",30)
print(obj.age)
print(obj. __doc__)



class A(object):
    def __init__(self):
        self.str1='abc';
        print('object created',self.str1)
    def __del__(self):
        print('Destructor is called manually')


ob=A()
del ob