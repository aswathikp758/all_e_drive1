x=5
y="hello"

print(x)
print(y)

x=str(3)
y=int(3)
z=float(3)
print(x)
print(y)
print(z)

print(type(x))




a=4
A="hello"
print(a)
print(A)

x,y,z="html","css","js"
print(x)
print(y)
print(z)

x=y=z="html"
print(x)
print(y)
print(z)

language=["html","css","js"]
x,y,z=language
print(x)
print(y)
print(z)

x="programing language"
def myfun():
    x="markup language"
    print("html is "+x)

myfun()
print("html is "+x)
x="hello world"
print(len(x))

mylist=["a","b","c"]
print(mylist)
print(mylist[0])
print(type(mylist))

mytuple=("a","b","c")
print(mytuple)

myset={"x","y","z"}
print(myset)
print(type(myset))

mydict={
    "letter":"a",
    "number":"123"
}
print(mydict["letter"])


a=30
b=30
if b>a:
    print("b is grater than a")
elif a==b:
    print("a is  equal to b")
else:
    print("error")


i=1
while i<6:
    print(i)
    i+=1

language=["html","css","js"]
for x in language:
    print(x)

def index(a,b,c):
    print("hello "+a)

index(a="hai",b="world",c="hello")

def my_function(letters):
    for x in letters:
        print(x)

letter=["a","b","c"]
my_function(letter)


class Myclass:
    x=5

p1=Myclass()
print(p1.x)

# class classname:
#     def __init__(self):


class Home:
    x=5
    y=10
    z=20
    def index(self):
        print("hello")

h1=Home()
print(h1.y)
h1.index()
h1.x=50
print(h1.x)
del h1.x
print(h1.x)

# print(p.__doc__)

class A(object):
    def __init__(self):
        self.str1='abc'
        print('object created',self.str1)

    def __del__(self):
        print('destructor is called ')

ob=A()
del ob

class person:
    def __init__(self,fname,lname):
        self.firstname=fname
        self.lastname=lname

    def printname(self):
        print(self.firstname,self.lastname)




class student(person):
    pass

x=student("john","alex")
x.printname()


class Langauge:
    def lang(self):
        print("programming language")

class html(Langauge):
    def lang(self):
        print("markup language")
class css(Langauge):
    def lang(self):
        print("style sheet language")
class pyhton(Langauge):
    def lang(self):
        print("backend language")


html=html()
html.lang()
css=css()
css.lang()

# f=open("demofile.txt","a")
# f.write("helllo python!!!!")
# f.close()
#
# f=open("demofile.txt","r")
# print(f.read())


#f=open("newfile.txt","x")


#import os
# # os.remove("demofile.txt")
# if os.path.exists("demofile.txt"):
#     os.remove("demofile.txt")
# else:
#     print("the file doen not exist")

# os.getcwd()
# print(os.getcwd())

import re
txt=" rain in pain"
x=re.search("^The.*Spain$",txt)
if x:
    print("yes")
else:
    print("no match")

# os.chdir("C://Users/anand/PycharmProjects/pythonBasics/sample")
# print(os.getcwd())

# listdir=os.listdir("C://Users/anand/PycharmProjects/pythonBasics")
# print(listdir)
# os.mkdir('test')
# os.rename('test','sample')

# import re
# # txt="The rain in Spain"
# # x=re.sub("\s","8",txt)
# # print(x)
# pattern='^a...s$'
# text_string='abysdfdfs'
# result=re.match(pattern,text_string)
# if result:
#     print("success")
# else:
#     print("unsuccess")


from mymodule import person1
print(person1["age"])

# import platform
# x=platform.system()
# print(x)












