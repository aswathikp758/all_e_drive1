x="python"

def index():
    x = "haii"
    print("hello " + x)


index()

print(x)

a=str(3)
a="3"
b=int(3)
z=float(3)
index()
print(a);

language=["html","php","python",60]
print(language[-1])

mytuple=("a","b","c")
print(mytuple)
print(len(mytuple))
print(type(mytuple))

myset={"a","b","c"}
print(myset)
print(type(myset))
print(len(myset))