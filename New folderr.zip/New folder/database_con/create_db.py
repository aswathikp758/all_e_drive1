import mysql.connector

# mydb = mysql.connector.connect(host="localhost", user="ram", password="")
mydb=mysql.connector.connect(user='root', password='', host='localhost', port='3306', database='blog')

# print(mydb)
# if(mydb):
#   print("connection success")
# else:
#   print("error")

mycursor = mydb.cursor()

mycursor.execute("CREATE DATABASE mydatabase")

