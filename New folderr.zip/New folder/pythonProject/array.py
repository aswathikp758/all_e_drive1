#Arrays are used to store multiple values in one single variable:


#Create an array containing car names:

cars = ["Ford", "Volvo", "BMW"]
