#Arithmetic operators
#Assignment operators
#Comparison operators
#Logical operators
#Identity operators
#Membership operators
#Bitwise operators


#ARITHMATIC OPERATOR
x = 5
y = 3

print(x + y)#addition

x = 5
y = 3

print(x - y)#subtration

x = 5
y = 3

print(x * y)#multiplication

x = 5
y = 3

print(x / y)#division


#ASSIGNMENT OPERATOR
x = 5

print(x)#=

x = 5

x += 3

print(x)#+=

#comparison operator
x = 5
y = 3

print(x == y)

# returns False because 5 is not equal to 3

x = 5
y = 3

print(x != y)

# returns True because 5 is not equal to 3

x = 5
y = 3

print(x > y)

# returns True because 5 is greater than 3

x = 5
y = 3

print(x < y)

# returns False because 5 is not less than 3

x = 5
y = 3

print(x >= y)

# returns True because five is greater, or equal, to 3

x = 5
y = 3

print(x <= y)

# returns False because 5 is neither less than or equal to 3

#LOGICAL OPEARATOR
x = 5

print(x > 3 and x < 10)

# returns True because 5 is greater than 3 AND 5 is less than 10

x = 5

print(x > 3 or x < 4)

# returns True because one of the conditions are true (5 is greater than 3, but 5 is not less than 4)

x = 5

print(not(x > 3 and x < 10))

# returns False because not is used to reverse the result

#IDENTITY OPERATOR
#is
x = ["apple", "banana"]
y = ["apple", "banana"]
z = x

print(x is z)

# returns True because z is the same object as x

print(x is y)

# returns False because x is not the same object as y, even if they have the same content

print(x == y)

# to demonstrate the difference betweeen "is" and "==": this comparison returns True because x is equal to y


#isnot
x = ["apple", "banana"]
y = ["apple", "banana"]
z = x

print(x is not z)

# returns False because z is the same object as x

print(x is not y)

# returns True because x is not the same object as y, even if they have the same content

print(x != y)

# to demonstrate the difference betweeen "is not" and "!=": this comparison returns False because x is equal to y


#MEMBERSHIP OPERATOR
#in
x = ["apple", "banana"]

print("banana" in x)

# returns True because a sequence with the value "banana" is in the list

#notin
x = ["apple", "banana"]

print("pineapple" not in x)

# returns True because a sequence with the value "pineapple" is not in the list


#Python Bitwise Operators
#Bitwise operators are used to compare (binary) numbers:

#& 	AND	Sets each bit to 1 if both bits are 1
#|	OR	Sets each bit to 1 if one of two bits is 1
# ^	XOR	Sets each bit to 1 if only one of two bits is 1
#~ 	NOT	Inverts all the bits
#<<	Zero fill left shift	Shift left by pushing zeros in from the right and let the leftmost bits fall off
#>>	Signed right shift	Shift right by pushing copies of the leftmost bit in from the left, and let the rightmost bits fall off
