#Lists are used to store multiple items in a single variable.

thislist = ["apple", "banana", "cherry"]
print(thislist)

#List Length
#To determine how many items a list has, use the len() function:

thislist = ["apple", "banana", "cherry"]
print(len(thislist))

#datatype of list
#<class 'list'>

mylist = ["apple", "banana", "cherry"]
print(type(mylist))

#Access Items
#List items are indexed and you can access them by referring to the index number:


thislist = ["apple", "banana", "cherry"]
print(thislist[0])

#Negative Indexing
#Negative indexing means start from the end

#-1 refers to the last item, -2 refers to the second last item etc.

thislist = ["apple", "banana", "cherry"]
print(thislist[-1])

#Range of index
thislist = ["apple", "banana", "cherry", "orange", "kiwi", "melon", "mango"]
print(thislist[2:5])

#Check if "apple" is present in the list:

thislist = ["apple", "banana", "cherry"]
if "apple" in thislist:
  print("Yes, 'apple' is in the fruits list")

  #Change the second item:

thislist = ["apple", "banana", "cherry"]
thislist[1] = "blackcurrant"
print(thislist)

#Change the second value by replacing it with two new values:

thislist = ["apple", "banana", "cherry"]
thislist[1:2] = ["blackcurrant", "watermelon"]
print(thislist)

#Using the append() method to append an item:

thislist = ["apple", "banana", "cherry"]
thislist.append("orange")
print(thislist)

#Insert an item as the second position:

thislist = ["apple", "banana", "cherry"]
thislist.insert(1, "orange")
print(thislist)

#Remove list item:

thislist = ["apple", "banana", "cherry"]
thislist.remove("banana")
print(thislist)
