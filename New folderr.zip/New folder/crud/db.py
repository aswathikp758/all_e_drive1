import psycopg2
con=psycopg2.connect(
    host="localhost",
    database="Crud_db",
    user="postgres",
    password="1234"
)
cur=con.cursor()
cur.execute("insert into employees (id,name) values(%s,%s)",(4,"nmb"))

cur.execute("select id,name from employees")
rows =cur.fetchall()

for r in rows:
    print (f"id {r[0]} name {r[1]}")

con.commit()

con.close()