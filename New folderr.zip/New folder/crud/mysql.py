import mysql.connector
con=mysql.connector.connect(
    host="localhost",
    database="demo",
    username="root",
    password=""
)
print(con)