#you can filter the selection by using the "WHERE" statement:
import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    username="root",
    password="",
    database="python_db"
)

mycursor = mydb.cursor()

sql = "SELECT * FROM customers WHERE address ='Sky st 331'"

mycursor.execute(sql)

myresult = mycursor.fetchall()

for x in myresult:
  print(x)
