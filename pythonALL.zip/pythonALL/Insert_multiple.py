import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    username="root",
    password="",
    database="my_database"
)
mycursor = mydb.cursor()

sql = "INSERT INTO customers (id,name, address) VALUES (%s,%s, %s)"
val = [
 ('2','Peter', 'Lowstreet 4'),
 ('3','Amy', 'Apple st 652'),
 ('4','Hannah', 'Mountain 21'),
 ('5','Michael', 'Valley 345'),
 ('6','Sandy', 'Ocean blvd 2'),
 ('7','Betty', 'Green Grass 1'),
 ('8','Richard', 'Sky st 331'),

]

mycursor.executemany(sql, val)

mydb.commit()

print(mycursor.rowcount, "record was inserted.")