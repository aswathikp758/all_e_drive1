import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    username="root",
    password="",
    database="my_database"
)

mycursor = mydb.cursor()

sql = "UPDATE customers SET name='abc',address = 'skyline 123' WHERE id = '1'"

mycursor.execute(sql)

mydb.commit()

print(mycursor.rowcount, "record(s) affected")