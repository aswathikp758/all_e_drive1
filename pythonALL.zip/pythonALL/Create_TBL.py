import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  username="root",
  password="",
  database="my_database2"


)

mycursor = mydb.cursor()

mycursor.execute("CREATE TABLE customers (id int(11),name VARCHAR(255), address VARCHAR(255))")

#If this page is executed with no error, you have successfully created a table named "customers".