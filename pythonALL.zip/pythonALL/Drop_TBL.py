import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    username="root",
    password="",
    database="python_db"
)

mycursor = mydb.cursor()

sql = "DROP TABLE customers"

#Delete the table "customers" if it exists:
sql = "DROP TABLE IF EXISTS customers"

mycursor.execute(sql)