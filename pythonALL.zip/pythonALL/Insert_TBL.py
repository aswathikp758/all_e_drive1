import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    username="root",
    password="",
    database="my_database2"
)


mycursor = mydb.cursor()

sql = "INSERT INTO customers (id,name,address) VALUES (%s,%s,%s)"
val = ("1","John", "Highway 21")

mycursor.execute(sql, val)

mydb.commit()

print(mycursor.rowcount, "record inserted.")
