from tkinter import *

window=Tk()

window.title("first app")
window.configure(bg="pink")
window.geometry("500x500")
#
def hello():
    print("button clicked")

# button=Button(window,text="Submit",height="5",width="5",bg="red",command=hello)

button1=Button(window,text="Submit",command=hello)
button2=Button(window,text="Submit",command=hello)
button1.grid(row=0,column=0)
button2.grid(row=0,column=1)


# label=Label(window,text="welcome")
# button.pack()
# label.pack()

window.mainloop()