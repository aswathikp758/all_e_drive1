import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    username="root",
    password="",
    database="my_database"
)

mycursor = mydb.cursor()

sql = "SELECT user.id,user.name, product.name FROM user INNER JOIN product ON user.fav=product.id;"
# SELECT column_name(s) FROM table1 INNER JOIN table2 ON table1.column_name = table2.column_name;

mycursor.execute(sql)

myresult = mycursor.fetchall()

for x in myresult:
  print(x)