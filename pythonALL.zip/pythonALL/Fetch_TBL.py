import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    username="root",
    password="",
    database="my_database"
)

mycursor = mydb.cursor()

mycursor.execute("SELECT * FROM customers")
# mycursor.execute("SELECT name,address FROM customers")

#  fetch all data
myresult = mycursor.fetchall()

#fetch first row
# myresult = mycursor.fetchone()

for x in myresult:
  print(x)
