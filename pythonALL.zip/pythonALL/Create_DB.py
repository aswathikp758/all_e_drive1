# database creation using mysql ,xampp server
import mysql.connector

mydb=mysql.connector.connect(
    host="localhost",
    username="root",
    password=""
)
# print(mydb)
mycursor =mydb.cursor()
mycursor.execute("create database my_database2")
print("database created")