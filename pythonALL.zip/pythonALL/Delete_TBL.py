#Delete any record where the address is "Mountain 21":

import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    username="root",
    password="",
    database="my_database"
)

mycursor = mydb.cursor()

sql = "DELETE FROM customers WHERE id = '7'"

mycursor.execute(sql)

mydb.commit()
#mydb.commit(). It is required to make the changes, otherwise no changes are made to the table.

print(mycursor.rowcount, "record(s) deleted")