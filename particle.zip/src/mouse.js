import React from 'react'
import mainscript from './mainscript.js'

export default function mouse() {
  return (
    <div>

       <canvas id="header-canvas"></canvas>

    </div>
  )
}
