import logo from './logo.svg';
import './App.css';
import Particle from './particle/Particle';

function App() {
  return (
    <div className="App">
     <Particle/> 
    </div>
  );
}

export default App;
